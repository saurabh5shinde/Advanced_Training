-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 18, 2022 at 10:00 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `Book_id` varchar(10) NOT NULL,
  `Book_name` varchar(50) NOT NULL,
  `Author` varchar(60) NOT NULL,
  `Price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`Book_id`, `Book_name`, `Author`, `Price`) VALUES
(' 1 ', 'Let Us C', 'Yashavant P. Kanetkar ', 200),
(' 10 ', 'SQL : The Complete References', ' James Groff ', 667),
(' 2 ', 'Thinking in Java', 'Thinking in Java', 300),
(' 3 ', 'Computer Networking', 'James F. Kurose', 250),
(' 4 ', 'Head First C#', 'Andrew Stellman ', 400),
(' 5', 'What is HTML5 ?', 'Brett Mclaughlin ', 300),
(' 6 ', 'HTML in Action', 'Joe Lennon ', 569),
(' 7 ', 'OOP with C++', 'Balagurusamy ', 308),
(' 8 ', 'C++ : The Complete Reference', 'Herbert Schildt ', 532),
(' 9 ', 'Head First SQl', 'Lynn Beighley ', 450);

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `Order_Id` int(11) NOT NULL,
  `address` varchar(50) NOT NULL,
  `mobileno` int(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `Order_Date` date NOT NULL,
  `Quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`Order_Id`, `address`, `mobileno`, `name`, `Order_Date`, `Quantity`) VALUES
(1, ' Radhika Vihar ', 2147483647, 'Amit ', '2016-11-08', 3),
(2, ' Rakshak Nagar ', 875451395, ' Mona ', '2016-11-08', 3),
(3, ' Rakshak Nagar Gold', 2147483647, ' Kavi ', '2016-11-08', 2),
(4, ' Bangalore ', 784512788, 'Monalisa', '2016-11-08', 3),
(5, ' Wadganosheri ', 784578215, ' Amol ', '2016-11-08', 3),
(6, ' Bangalore ', 78521868, 'Amit ', '2016-11-08', 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `first_name` varchar(10) NOT NULL,
  `address` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `registration_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`first_name`, `address`, `email`, `user_name`, `password`, `registration_date`) VALUES
('Amit ', 'Wagholi ', 'amit.mishra369@gmail.com', '9673960407 ', 'mona9Dutta ', '2016-11-08'),
('Hari', 'Chandan Nagar ', 'hari39@rediffmail.com', '7845127421', 'Adam99@ ', '2016-11-08'),
('Monalisa ', 'Rakshak Nagar ', 'mona9@gmail.com', '9878454503', 'pinaki9@ ', '2016-11-08'),
('Narendra ', 'Rajpath ', 'narendra17@pmo.nic.in', '8877990011 ', '	Delhi9% ', '2016-11-08'),
('Kavita ', 'Rakshak Nagar Gold ', 'kavi23@gmail.com', '98978521402', 'Alia8& ', '2016-11-08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`Book_id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`Order_Id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
